<?php

// For help about this file, check:
// http://apps.meow.fr/media-file-renamer/faq/

// add_filter( 'mfrh_new_filename', 'add_hello_in_front_of_filenames', 10, 3 );
//
// function add_hello_in_front_of_filenames( $new, $old, $post ) {
//   return "hello-" . $new;
// }

// add_action( 'mfrh_url_renamed', 'url_of_media_was_modified', 10, 3 );
//
// function url_of_media_was_modified( $post, $orig_image_url, $new_image_url ) {
//
// }

// add_action( 'mfrh_media_renamed', 'filepath_of_media_was_modified', 10, 3 );
//
// function filepath_of_media_was_modified( $post, $orig_image_url, $new_image_url ) {
//
// }

?>
