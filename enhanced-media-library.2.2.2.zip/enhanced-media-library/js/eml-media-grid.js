( function( $ ) {    
    
    $( document ).ready( function() {
        
        $('.media-toolbar.wp-filter .media-grid-view-switch').after( $('.media-toolbar.wp-filter .select-mode-toggle-button') ); 
    });

})( jQuery );